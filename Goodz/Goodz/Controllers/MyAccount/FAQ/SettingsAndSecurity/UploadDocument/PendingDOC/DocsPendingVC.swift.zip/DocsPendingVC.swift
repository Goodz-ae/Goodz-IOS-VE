//
//  DocsPendingVC.swift
//  Goodz
//
//  Created by shobhitdhuria on 31/01/25.
//

import UIKit

class DocsPendingVC: BaseVC {

    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var uploadDocsLbl: UILabel!
    @IBOutlet weak var homeBtn: ThemeGreenBorderButton!
    @IBOutlet weak var uploadDocsBtn: ThemeGreenButton!
    
    var fromSellVc: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setUpUI()
        // Do any additional setup after loading the view.
    }
    
    //-------------------------------
    // MARK: - UI Setup
    
    func setUpUI() {
        if !self.fromSellVc {
            self.view.backgroundColor = .black.withAlphaComponent(0.6)
        } else {
            self.view.backgroundColor = .systemBackground
        }
        
        self.backgroundView.cornerRadius = 10
        
        self.uploadDocsLbl.font(font: .semibold, size: .size18)
        self.uploadDocsLbl.color(color: .themeBlack)
        
        self.homeBtn.setTitle(Labels.backToHome, for: .normal)
        self.uploadDocsBtn.setTitle(Labels.uploadDocuments, for: .normal)
    }
    
    //-------------------------------
    // MARK: - Actions
    
    @IBAction func disBtnAction(_ sender: Any) {
        if !self.fromSellVc {
            self.dismiss(animated: true)
        } else {
            self.coordinator?.setTabbar(selectedIndex: 0)
        }
    }
    
    @IBAction func homeBtnAction(_ sender: Any) {
        if !self.fromSellVc {
            self.dismiss(animated: true)
        } else {
            self.coordinator?.setTabbar(selectedIndex: 0)
        }
    }
    
    @IBAction func uploadDocsBtnAction(_ sender: Any) {
        self.dismiss(animated: true, completion: {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
                self.coordinator?.navigateToUploadDocument(isPro: appUserDefaults.getValue(.isProUser) ?? false)
            })
        })
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
