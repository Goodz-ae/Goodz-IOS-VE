//
//  DocHelpCenterViewCont.swift
//  Goodz
//
//  Created by Dipesh Sisodiya on 03/02/25.
//

import UIKit

class DocHelpCenterViewCont : BaseVC  {
    
    @IBOutlet weak var appTopView: AppStatusView!
    @IBOutlet weak var emiratesIDBGView: UIView!
    @IBOutlet weak var emiratesIDLbl: UILabel!
    @IBOutlet weak var bankLetterBGView: UIView!
    @IBOutlet weak var bankLetterLbl: UILabel!
    @IBOutlet weak var bankAccountBGView: UIView!
    @IBOutlet weak var bankAccountLbl: UILabel!
    @IBOutlet weak var descBGView: UIView!
    @IBOutlet weak var descLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setUpUI()
        // Do any additional setup after loading the view.
    }
    
    func setUpUI() {
        
        self.setTopViewAction()
        
        self.emiratesIDLbl.font(font: .medium, size: .size16)
        self.emiratesIDLbl.color(color: .themeBlack)
        
        self.bankLetterLbl.font(font: .medium, size: .size16)
        self.bankLetterLbl.color(color: .themeBlack)
        
        self.bankAccountLbl.font(font: .medium, size: .size16)
        self.bankAccountLbl.color(color: .themeBlack)
        
        self.descLbl.font(font: .regular, size: .size14)
        self.descLbl.lineBreakMode = .byWordWrapping
        let text = """
        Why do we need these Documents for every seller?

        These documents are required by the Payment providers and UAE laws to be able to pay you for every sale you are making in Goodz.

        Emirates ID:
        Your Emirates ID confirms your Identity and ensures a secure experience for the community.

        Bank Letter:
        To verify that the bank account provided is valid and belongs to you ensuring smooth and secure payment.

        Bank Account:
        Allows us to transfer your earning directly to your bank account safely and fastly.

        Private Policy:
        Your information is used solely for verification and is never shared without your consent.
        """

        let attributedText = NSMutableAttributedString(string: text)

        // Define attributes for bold text
        if let customBoldFont = UIFont(name: "Poppins-SemiBold", size: 16) {
            let boldAttributes: [NSAttributedString.Key: Any] = [.font: customBoldFont]
            
            // Apply bold formatting to specific words
            let boldTexts = ["Why do we need these Documents for every seller?",
                             "Emirates ID:",
                             "Bank Letter:",
                             "Bank Account:",
                             "Private Policy"]
            
            for boldText in boldTexts {
                if let range = text.range(of: boldText) {
                    let nsRange = NSRange(range, in: text)
                    attributedText.addAttributes(boldAttributes, range: nsRange)
                }
            }
        }
        // Assign the attributed text to your UILabel
        self.descLbl.attributedText = attributedText
        
        self.emiratesIDBGView.roundTopCorners(radius: 5)
        self.bankAccountBGView.roundBottomCorners(radius: 5)
        
        addTapGesture(to: emiratesIDBGView, action: #selector(emiratesIDBGViewTapped))
        addTapGesture(to: bankLetterBGView, action: #selector(bankLetterBGViewTapped))
        addTapGesture(to: bankAccountBGView, action: #selector(bankAccountBGTapped))
            
    }
    
    func setTopViewAction() {
        self.appTopView.textTitle = Labels.myDocs
        self.appTopView.backButtonClicked = {
            self.coordinator?.popVC()
        }
    }
    
    // Function to add tap gesture to a view
    private func addTapGesture(to view: UIView, action: Selector) {
        let tapGesture = UITapGestureRecognizer(target: self, action: action)
        view.isUserInteractionEnabled = true // Ensure interaction is enabled
        view.addGestureRecognizer(tapGesture)
    }
    
    // Gesture Handlers
    @objc func emiratesIDBGViewTapped() {
        print("First view tapped!")
        self.coordinator?.navigateToUploadDocument(isPro: appUserDefaults.getValue(.isProUser) ?? false)
    }
    
    @objc func bankLetterBGViewTapped() {
        print("Second view tapped!")
        self.coordinator?.navigateToBankLetter()
    }
    
    @objc func bankAccountBGTapped() {
        print("Third view tapped!")
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
