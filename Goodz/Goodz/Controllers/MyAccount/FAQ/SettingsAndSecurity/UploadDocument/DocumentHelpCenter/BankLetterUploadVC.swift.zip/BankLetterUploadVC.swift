//
//  BankLetterUploadVC.swift
//  Goodz
//
//  Created by Dipesh on 04/02/25.
//

import UIKit

class BankLetterUploadVC: BaseVC {

    @IBOutlet weak var appTopView: AppStatusView!
    
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var bankLetterLbl: UILabel!
    @IBOutlet weak var bankLetterUploadBtn: SmallGreenBorderButton!
    
    @IBOutlet weak var bankLetterRemoveView: UIView!
    @IBOutlet weak var bankLetterDocBtn: SmallGreenButton!
    @IBOutlet weak var bankLetterCrossBtn: UIButton!
    
    @IBOutlet weak var agreeBtn: UIButton!
    @IBOutlet weak var agreeLbl: UILabel!
    
    @IBOutlet weak var uploadValidateBtn: ThemeGreenButton!
    
    
    var bankLetterUrl: URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUp()
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    // --------------------------------------------
    
    private func setUp() {
        self.applyStyle()
        self.setData()
//        self.setTopButton()
        self.setTopViewAction()
        self.setBankLetterDoc()
    }
    
    // --------------------------------------------
    
    private func applyStyle() {
//        if appUserDefaults.codableObject(dataType : CurrentUserModel.self,key: .currentUser)?.documentsSubmitted == "0" {
//            self.btnRequest.isSelected = true
//        } else {
//            self.vwMain.isHidden = true
//            self.btnUpload.isSelected = true
//            self.apiCalling(isUploadDocument: true)
//        }
        self.bankLetterLbl.font(font: .medium, size: .size14)
        self.bankLetterLbl.color(color: .themeBlack)
        
        
        self.agreeLbl.font(font: .regular, size: .size14)
        self.agreeLbl.color(color: .themeGray)
        
    }
    
    // --------------------------------------------
    
    private func setData() {
        
        self.titleLbl.text = Labels.pleaseUploadYourBankLetter
        self.agreeLbl.text = Labels.iHerebyCertifiedThatAll
        
        self.agreeBtn.setImage(.iconUncheckBox, for: .normal)
        self.agreeBtn.setImage(.iconCheckSquare, for: .selected)
        
        self.agreeBtn.addTapGesture {
            self.agreeBtn.isSelected.toggle()
        }
        
        self.bankLetterLbl.text = Labels.bankLettermandat
        self.bankLetterUploadBtn.setTitle(Labels.upload, for: .normal)
        self.bankLetterUploadBtn.setImage(.iconUpload, for: .normal)
        
        self.bankLetterDocBtn.setImage(.iconCrossSmall, for: .normal)
        
        self.titleLbl.setAttributeText(fulltext: Labels.pleaseUploadYourBankLetter, range1: Labels.pleaseUploadYour, range2: Labels.letter.capitalizeFirstLetter(), range3: Labels.toBeginverificationProcess.lowercaseFirstLetter())
        self.uploadValidateBtn.setTitle(Labels.uploadMyDocuments, for: .normal)
        self.bankLetterDocBtn.superview?.isHidden = true
    
    }
    
    // --------------------------------------------
    
    func setBankLetterDoc() {
        self.bankLetterUploadBtn.addTapGesture {
            self.setOpenLibrary() { url in
                self.bankLetterDocBtn.superview?.isHidden = false
                self.bankLetterDocBtn.setTitle(url?.lastPathComponent, for: .normal)
                self.bankLetterUrl = url
                self.bankLetterUploadBtn.isHidden = true
            }
        }
        self.bankLetterCrossBtn.addTapGesture {
            self.bankLetterDocBtn.superview?.isHidden = true
            self.bankLetterUrl = nil
            self.bankLetterUploadBtn.isHidden = false
        }
    }
    
    // --------------------------------------------
    
    func setOpenLibrary(completion: @escaping ((URL?) -> Void)) {
        AttachmentHandler.shared.showAttachmentActionSheet(type: [.camera, .phoneLibrary,.file], vc: self)
        AttachmentHandler.shared.imagePickedBlock = { (img,imgUrl) in
            print(img)
            completion(imgUrl)
        }
        AttachmentHandler.shared.filePickedBlock = { (fileType, url, img) in
           print(url)
            completion(url)
        }
    }
    
    // --------------------------------------------
    
    func setTopViewAction() {
        self.appTopView.textTitle = Labels.bankLetter
        self.appTopView.backButtonClicked = {
            self.coordinator?.popVC()
        }
    }
    
    
    //---------------------------------------------
    // MARK: - Actions
    
    @IBAction func bankLetterUploadBtnAction(_ sender: Any) {
    }
    
    @IBAction func bankLetterDocBtnAction(_ sender: Any) {
    }
    
    @IBAction func bankLetterCrossBtnAction(_ sender: Any) {
    }
    
    @IBAction func agreeBtnAction(_ sender: Any) {
    }
    
    @IBAction func uploadValidateBtnAction(_ sender: Any) {
    }
    
    
    
}
